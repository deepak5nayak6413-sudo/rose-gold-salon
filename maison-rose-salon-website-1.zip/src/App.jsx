import React, { useState } from 'react';
import { ArrowDownRight, ArrowRight, Check, Clock3, Instagram, MapPin, Menu, Scissors, Sparkles, Star, X } from 'lucide-react';
import { supabase } from './supabase';

const services = [
  { no:'01', name:'Signature Haircut', detail:'A considered cut, tailored to your texture and lifestyle.', time:'45 min', price:'₹899', tag:'MOST LOVED' },
  { no:'02', name:'Hair Ritual & Blowout', detail:'Deep nourishment, glossy finish and a little extra confidence.', time:'60 min', price:'₹1,499' },
  { no:'03', name:'The Rose Facial', detail:'A restorative skin ritual for a fresh, luminous complexion.', time:'50 min', price:'₹1,799', tag:'GLOW FAVOURITE' },
  { no:'04', name:'Manicure & Gel Finish', detail:'Immaculate details with a long-lasting, high-shine finish.', time:'45 min', price:'₹999' },
];
const gallery = [
  { title:'The art of the blowout', cls:'photo-one' },
  { title:'Quiet luxury, always', cls:'photo-two' },
  { title:'A little rose-gold glow', cls:'photo-three' },
];

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [bookingOpen, setBookingOpen] = useState(false);
  const [status, setStatus] = useState('');
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({ name:'', phone:'', service:'Signature Haircut', date:'', time:'11:00', notes:'' });
  const whatsapp = (import.meta.env.VITE_WHATSAPP_NUMBER || '').replace(/\D/g, '');
  const openBooking = (service) => { setForm(f => ({ ...f, service: service || f.service })); setStatus(''); setBookingOpen(true); };
  const change = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  async function submitBooking(e) {
    e.preventDefault(); setBusy(true); setStatus('');
    const payload = { customer_name: form.name.trim(), phone: form.phone.trim(), service_name: form.service, appointment_date: form.date, appointment_time: form.time, notes: form.notes.trim() || null };
    if (supabase) {
      const { error } = await supabase.from('bookings').insert(payload);
      if (error) { setStatus('We couldn’t save this booking yet. Please check your Supabase setup or message us directly.'); setBusy(false); return; }
      setStatus('Your request is in! We’ll contact you shortly to confirm your appointment.');
    } else if (whatsapp) {
      const message = `Hi Maison Rose! I'd like to request an appointment.%0AName: ${encodeURIComponent(payload.customer_name)}%0APhone: ${encodeURIComponent(payload.phone)}%0AService: ${encodeURIComponent(payload.service_name)}%0ADate: ${encodeURIComponent(payload.appointment_date)}%0ATime: ${encodeURIComponent(payload.appointment_time)}%0ANotes: ${encodeURIComponent(payload.notes || 'None')}`;
      window.open(`https://wa.me/${whatsapp}?text=${message}`, '_blank', 'noopener,noreferrer');
      setStatus('Your booking message is ready in WhatsApp. Send it there to complete your request.');
    } else {
      setStatus('Connect Supabase using the included .env.example, or add your WhatsApp number in .env to receive booking requests.');
    }
    setBusy(false);
  }

  return <div className="site-shell">
    <div className="announcement"><Sparkles size={13} /> A LITTLE LUXURY, JUST FOR YOU <span className="announcement-dot">✦</span> NOW ACCEPTING APPOINTMENTS</div>
    <header className="header">
      <a href="#home" className="brand" aria-label="Maison Rose home"><span className="brand-mark">M<span>R</span></span><span className="brand-name">MAISON <b>ROSE</b><small>BEAUTY • HAIR • SKIN</small></span></a>
      <nav className={menuOpen ? 'nav nav-open' : 'nav'}>
        <a href="#services" onClick={()=>setMenuOpen(false)}>Services</a><a href="#story" onClick={()=>setMenuOpen(false)}>Our philosophy</a><a href="#space" onClick={()=>setMenuOpen(false)}>The space</a><a href="#visit" onClick={()=>setMenuOpen(false)}>Visit us</a>
        <button className="nav-cta mobile-cta" onClick={()=>{openBooking();setMenuOpen(false)}}>Book a visit <ArrowRight size={15}/></button>
      </nav>
      <button className="nav-cta desktop-cta" onClick={()=>openBooking()}>Book a visit <ArrowRight size={15}/></button>
      <button className="menu-toggle" onClick={()=>setMenuOpen(!menuOpen)} aria-label="Toggle menu">{menuOpen?<X/>:<Menu/>}</button>
    </header>

    <main>
      <section className="hero" id="home">
        <div className="hero-image"></div><div className="hero-shade"></div>
        <div className="hero-content">
          <div className="eyebrow"><span></span> YOUR MOMENT. YOUR GLOW.</div>
          <h1>Beauty is an<br/><em>art of feeling.</em></h1>
          <p>A thoughtful pause from the everyday. Discover elevated hair, skin and self-care rituals in a space made for you.</p>
          <div className="hero-actions"><button className="button button-gold" onClick={()=>openBooking()}>Reserve your moment <ArrowRight size={17}/></button><a className="text-link" href="#services">Explore our rituals <ArrowDownRight size={17}/></a></div>
          <div className="hero-note"><div className="note-stars">★★★★★</div><span>Thoughtfully curated. Beautifully you.</span></div>
        </div>
        <div className="hero-side-note">THE MAISON ROSE EXPERIENCE <span>—</span> EST. WITH LOVE</div>
        <div className="hero-bottom"><span>01 / 03</span><span className="hero-bottom-line"></span><span>YOUR BEAUTY, REIMAGINED</span></div>
      </section>

      <section className="trust-strip"><div><span className="trust-icon"><Sparkles size={17}/></span><span><b>Personalised rituals</b><small>Made for your kind of beautiful</small></span></div><div><span className="trust-icon"><Star size={17}/></span><span><b>Considered quality</b><small>Thoughtful products, expert hands</small></span></div><div><span className="trust-icon"><Clock3 size={17}/></span><span><b>Your time, treasured</b><small>A calm escape from the everyday</small></span></div></section>

      <section className="services section-pad" id="services">
        <div className="section-heading"><div><div className="eyebrow dark-eyebrow"><span></span> THE MAISON MENU</div><h2>A ritual for<br/><em>every version of you.</em></h2></div><p>Little details make all the difference. Explore our signature treatments, thoughtfully designed to help you feel your very best.</p></div>
        <div className="service-list">{services.map(s=><article className="service-row" key={s.no}><span className="service-no">{s.no}</span><div className="service-title">{s.tag&&<span className="service-tag">{s.tag}</span>}<h3>{s.name}</h3><p>{s.detail}</p></div><span className="service-time"><Clock3 size={14}/>{s.time}</span><strong className="service-price">{s.price}</strong><button className="round-arrow" aria-label={`Book ${s.name}`} onClick={()=>openBooking(s.name)}><ArrowRight size={17}/></button></article>)}</div>
        <div className="services-bottom"><span>YOUR NEXT FAVOURITE RITUAL IS WAITING.</span><button className="text-link dark-link" onClick={()=>openBooking()}>Book a consultation <ArrowRight size={16}/></button></div>
      </section>

      <section className="story" id="story"><div className="story-photo"><div className="story-stamp"><span>MR</span><small>BEAUTY<br/>IN BALANCE</small></div></div><div className="story-copy"><div className="eyebrow"><span></span> OUR PHILOSOPHY</div><h2>Luxury isn't<br/>loud. It's <em>personal.</em></h2><p>We believe the best beauty experience starts with being seen, heard and understood. No rush. No one-size-fits-all. Just considered care, a little indulgence and results that still feel like you.</p><p>From the first hello to your final mirror moment, every detail is designed to make you feel at home in your own glow.</p><div className="signature">With love, <em>Maison Rose</em></div><button className="button button-outline" onClick={()=>openBooking()}>Come as you are <ArrowRight size={16}/></button></div></section>

      <section className="gallery section-pad" id="space"><div className="gallery-heading"><div><div className="eyebrow dark-eyebrow"><span></span> A SPACE TO EXHALE</div><h2>Consider this<br/><em>your little escape.</em></h2></div><p>Soft light, warm textures and the luxury of a moment that belongs only to you.</p></div><div className="gallery-grid">{gallery.map((g,i)=><div className={`gallery-card ${g.cls}`} key={g.cls}><div className="gallery-label"><span>0{i+1}</span><b>{g.title}</b></div></div>)}</div></section>

      <section className="quote-band"><span className="quote-mark">“</span><p>When you feel good in your own skin,<br/>it shows in everything you do.</p><span className="quote-rule"></span><small>A MAISON ROSE REMINDER</small></section>

      <section className="visit section-pad" id="visit"><div className="visit-copy"><div className="eyebrow dark-eyebrow"><span></span> COME FIND YOUR GLOW</div><h2>Your chair<br/>is <em>waiting.</em></h2><p>Whether it's your regular refresh or a little something special, we'd love to welcome you in.</p><div className="visit-detail"><MapPin size={18}/><div><b>Find our salon</b><span>Add your salon address here, your city</span></div></div><div className="visit-detail"><Clock3 size={18}/><div><b>Opening hours</b><span>Mon – Sun · 10:00 AM – 8:00 PM</span></div></div><button className="button button-dark" onClick={()=>openBooking()}>Plan your visit <ArrowRight size={16}/></button></div><div className="visit-image"></div></section>
    </main>

    <footer className="footer"><div className="footer-main"><a href="#home" className="brand footer-brand"><span className="brand-mark">M<span>R</span></span><span className="brand-name">MAISON <b>ROSE</b><small>BEAUTY • HAIR • SKIN</small></span></a><p>For the love of feeling<br/><em>beautifully yourself.</em></p><a className="social-link" href="https://instagram.com/" target="_blank" rel="noreferrer"><Instagram size={17}/> FOLLOW OUR WORLD <ArrowRight size={14}/></a></div><div className="footer-bottom"><span>© 2026 MAISON ROSE. MADE WITH CARE.</span><span>BEAUTY, WITH A SOFTER TOUCH.</span><a href="#home">BACK TO TOP ↑</a></div></footer>

    {bookingOpen&&<div className="modal-backdrop" role="presentation" onMouseDown={e=>{if(e.target===e.currentTarget)setBookingOpen(false)}}><div className="booking-modal" role="dialog" aria-modal="true" aria-labelledby="booking-title"><button className="modal-close" onClick={()=>setBookingOpen(false)} aria-label="Close booking form"><X/></button><div className="eyebrow dark-eyebrow"><span></span> YOUR MOMENT STARTS HERE</div><h2 id="booking-title">Let's make<br/><em>you time.</em></h2><p className="modal-intro">Request an appointment and our team will be in touch to confirm.</p><form onSubmit={submitBooking}><label>Your name<input name="name" required value={form.name} onChange={change} placeholder="Full name"/></label><label>Phone number<input name="phone" required value={form.phone} onChange={change} placeholder="+91 00000 00000" inputMode="tel"/></label><label>Choose your ritual<select name="service" value={form.service} onChange={change}>{services.map(s=><option key={s.no}>{s.name}</option>)}<option>Other / Consultation</option></select></label><div className="form-pair"><label>Preferred date<input name="date" type="date" min={new Date().toISOString().slice(0,10)} required value={form.date} onChange={change}/></label><label>Preferred time<select name="time" value={form.time} onChange={change}>{['10:00','11:00','12:00','13:00','14:00','15:00','16:00','17:00','18:00','19:00'].map(t=><option key={t} value={t}>{t}</option>)}</select></label></div><label>Anything we should know? <textarea name="notes" value={form.notes} onChange={change} placeholder="Optional notes" rows="2"/></label><button className="button button-dark submit-button" disabled={busy}>{busy?'Sending request…':'Request appointment'} <ArrowRight size={16}/></button>{status&&<div className="form-status" role="status"><Check size={16}/>{status}</div>}<small className="privacy-note">Your details are used only to manage your appointment request.</small></form></div></div>}
  </div>;
}

export default App;