# Maison Rose — Premium Salon Website

A responsive salon landing page with a rose-gold / warm-cream visual system, appointment request form, and Supabase booking storage. Uses Vite + React. **No Netlify required** — deploy to Vercel or Cloudflare Pages.

## Included
- Responsive premium salon website and mobile navigation
- Service menu with prices and appointment CTAs
- Appointment request modal
- Supabase `bookings` table and Row Level Security policy in `supabase/schema.sql`
- Optional WhatsApp fallback if Supabase isn't configured
- Vercel SPA rewrite config
- Environment variable example; no secrets included

## 1. Run locally
Install Node.js 20+ (or a current supported LTS version), then in this folder:

```bash
npm install
cp .env.example .env
npm run dev
```

Open the local URL Vite prints. On Windows, create `.env` by copying `.env.example` in File Explorer if `cp` isn't available.

## 2. Set up Supabase
1. Create a project at https://supabase.com/dashboard.
2. Open **SQL Editor → New query**.
3. Copy and run all of `supabase/schema.sql`.
4. Open **Project Settings → API** (or **Connect**, depending on dashboard layout).
5. Copy the Project URL and the publishable/anon key into `.env`:
   - `VITE_SUPABASE_URL=https://YOUR_PROJECT_ID.supabase.co`
   - `VITE_SUPABASE_ANON_KEY=YOUR_PUBLIC_PUBLISHABLE_OR_ANON_KEY`
6. Restart the dev server after editing `.env`.

The browser key is intended to be public. RLS is enabled and the policy permits visitors to INSERT appointment requests only. Do **not** place a `service_role` or secret key in any `VITE_` variable or frontend file. View booking records from the Supabase dashboard; a future custom admin panel should use Supabase Auth and carefully scoped policies.

## 3. Optional WhatsApp fallback
If you want booking requests to open WhatsApp when Supabase isn't configured, set `VITE_WHATSAPP_NUMBER` to your salon's country code + number, digits only (example format: `919876543210`). This is a placeholder format, not a real business number. Restart the dev server after changes.

## 4. Deploy without Netlify

### Option A — Vercel (recommended)
1. Push this folder to a GitHub repository.
2. Sign in to https://vercel.com/ and import the repository.
3. Framework preset: **Vite**; build command `npm run build`; output directory `dist`.
4. In Vercel **Project → Settings → Environment Variables**, add `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`, and optionally `VITE_WHATSAPP_NUMBER`.
5. Deploy. Redeploy after changing environment variables.

### Option B — Cloudflare Pages
1. Push this folder to GitHub and create a Pages project at https://pages.cloudflare.com/.
2. Build command `npm run build`; output directory `dist`.
3. Add the same `VITE_` environment variables in the Pages settings and deploy.

## 5. Personalise before launch
- Replace **Maison Rose** with your actual salon name.
- Update address, opening hours, prices, and contact details in `src/App.jsx`.
- Replace the Instagram destination and add the salon's actual social profile.
- The current visual photography uses remote Unsplash image URLs; replace with licensed salon photography for a real launch.
- Test an appointment from the deployed site and confirm it appears in Supabase.

## Security notes
- Never commit `.env`.
- Never expose a Supabase service-role key in the browser.
- Public form inserts are constrained by the RLS policy, but for a public production site also consider CAPTCHA/rate limiting and server-side validation to reduce spam.
- The frontend does not expose a public booking list or admin login.
