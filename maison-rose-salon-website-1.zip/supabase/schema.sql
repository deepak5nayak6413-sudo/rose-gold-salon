-- Maison Rose salon booking setup
-- Run this entire file in Supabase Dashboard -> SQL Editor -> New query.
create extension if not exists pgcrypto;

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  customer_name text not null check (char_length(customer_name) between 2 and 100),
  phone text not null check (char_length(phone) between 7 and 25),
  service_name text not null check (char_length(service_name) between 2 and 120),
  appointment_date date not null,
  appointment_time text not null,
  notes text,
  status text not null default 'pending' check (status in ('pending','confirmed','completed','cancelled')),
  created_at timestamptz not null default now()
);

alter table public.bookings enable row level security;

-- Public website visitors may submit a booking request only.
-- They cannot read bookings or change status/customer details after insertion.
drop policy if exists "Visitors can request appointments" on public.bookings;
create policy "Visitors can request appointments"
on public.bookings for insert
to anon, authenticated
with check (
  char_length(customer_name) between 2 and 100
  and char_length(phone) between 7 and 25
  and char_length(service_name) between 2 and 120
  and appointment_date >= current_date
  and status = 'pending'
);

-- Intentionally do not create public SELECT/UPDATE/DELETE policies.
-- Manage/view bookings while signed into Supabase Dashboard, or add a secured
-- admin workflow with Supabase Auth before building a custom admin panel.

create index if not exists bookings_appointment_date_idx
on public.bookings (appointment_date);

create index if not exists bookings_created_at_idx
on public.bookings (created_at desc);